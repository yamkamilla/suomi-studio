# Handoff: Suomi Studio — Glass Redesign

## Overview
A full visual + interaction redesign of **Suomi Studio**, the personal Finnish-learning
PWA (translator · flashcards · notes · transcript import · 0–C1 grammar). The redesign
keeps every existing feature and the existing architecture, but replaces the flat
Material-ish UI with a **liquid-glass** aesthetic: frosted translucent cards and bars
(Telegram) layered over a soft animated aurora-blue backdrop (Apple Weather), springy
motion, and clean line icons in place of emoji.

The single design reference is `Suomi Studio.dc.html` (in this bundle). It is an
interactive prototype of all five tabs plus the settings/goals sheets.

## About the Design Files
`Suomi Studio.dc.html` is a **design reference created in HTML** — a prototype that
shows the intended look and behaviour. It is authored in a proprietary "Design Component"
format (a streaming `<x-dc>` template + a `class Component extends DCLogic` logic class)
and will **not** run outside that authoring tool. **Do not try to run it or copy it
verbatim.**

Your existing app already has a working, well-structured **vanilla-JS** frontend:
- `public/index.html` — markup / tab structure
- `public/style.css` — all styling (CSS custom properties in `:root`)
- `public/app.js` — all logic (translate, SRS, notes, import, grammar, storage)
- `public/grammar.js` — grammar curriculum data (`GRAMMAR_TOPICS`, `GRAMMAR_LEVELS`, `GRAMMAR_CHECKLIST`)
- `server.py` — tiny stdlib HTTP server: serves `public/`, `/api/data`, `/api/translate`, `/api/extract`

**The task is to re-skin and re-animate the existing app in place** — almost entirely a
`style.css` rewrite plus small, surgical `app.js`/`index.html` edits to swap emoji for
inline SVG icons and to add the bottom-sheet modals and card-flip. Keep the server,
storage, SRS algorithm, translation/extraction endpoints, and grammar data exactly as
they are. This is NOT a rewrite to React — stay in vanilla JS to match the codebase.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, radii, shadows, and interactions.
Recreate pixel-for-pixel using CSS. Every value below is exact.

---

## Design Tokens

Replace the `:root` block in `style.css` with these. Everything else references them.

```css
:root {
  /* brand blue */
  --blue:        #002f6c;   /* deep suomi blue — flag, primary text accents */
  --blue-mid:    #0b3f8f;   /* gradient bottom */
  --blue-bright: #2264c4;   /* gradient top, active states */
  --blue-link:   #1a55a5;   /* links, secondary actions */

  /* ink */
  --text:   #16233f;        /* primary text */
  --muted:  #5b6a8c;        /* secondary text */
  --faint:  #8a94ad;        /* tertiary / metadata */

  /* status */
  --green:  #1f8a4c;  --green-bright: #27a55e;
  --red:    #c14a4a;
  --amber:  #c98a2b;

  /* glass surfaces — the core of the look */
  --card-bg:   rgba(255,255,255,.55);   /* translucent white */
  --card-bd:   rgba(255,255,255,.65);   /* light 1px border */
  --card-blur: blur(22px) saturate(1.5);/* backdrop-filter */
  --bar-bg:    rgba(255,255,255,.55);   /* header/tabbar tint */
  --bar-blur:  blur(24px) saturate(1.7);

  /* radii */
  --r-sheet: 30px;  --r-card: 22px;  --r-tile: 16px;
  --r-field: 18px;  --r-pill: 20px;  --r-btn: 18px;

  /* shadows */
  --sh-card:  0 8px 24px rgba(23,48,102,.08);
  --sh-float: 0 12px 32px rgba(23,48,102,.16), inset 0 1px 0 rgba(255,255,255,.7);
  --sh-btn:   0 8px 20px rgba(11,63,143,.3), inset 0 1px 0 rgba(255,255,255,.25);
}
```

**Backdrop** (on `body`, or an app-root layer behind the scrollable content):
```css
background: linear-gradient(168deg,#eef4fd 0%,#dce9fa 45%,#c9dcf5 100%);
```
Plus two blurred, slowly-drifting radial "blobs" for the aurora effect — absolutely
positioned, `filter: blur(70–80px)`, `opacity:.8`, `z-index` below content:
- Blob 1: 340×340, top-left (`left:-90px;top:-60px`), `radial-gradient(circle,rgba(120,170,240,.75),transparent 70%)`, `animation:blobA 16s ease-in-out infinite`
- Blob 2: 380×380, bottom-right (`right:-120px;bottom:60px`), `radial-gradient(circle,rgba(150,210,235,.65),transparent 70%)`, `animation:blobB 19s ease-in-out infinite`

```css
@keyframes blobA {0%,100%{transform:translate(0,0) scale(1)} 50%{transform:translate(40px,60px) scale(1.15)}}
@keyframes blobB {0%,100%{transform:translate(0,0) scale(1)} 50%{transform:translate(-50px,-40px) scale(1.1)}}
```

**Primary button** gradient + press:
```css
background: linear-gradient(180deg, var(--blue-bright), var(--blue-mid));
color:#fff; border:none; border-radius:var(--r-btn); font-weight:700;
box-shadow: var(--sh-btn);
/* press */ transition: transform .15s; }  button:active { transform: scale(.97); }
```

**Typography:** system font stack (unchanged):
`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`.
Scale used: screen title **28px/800**, letter-spacing −.4px · card front **30px/800** ·
result text **21px/700** · body **14–15px** · secondary **12.5–13.5px/muted** ·
metadata **11.5px/faint** · section label **11.5px/700**, uppercase, letter-spacing .8px ·
tab labels **9.5px/700**.

## Motion / animations
```css
@keyframes pop     {from{opacity:0;transform:translateY(16px) scale(.97)} to{opacity:1;transform:none}}
@keyframes rise    {from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:none}}
@keyframes fadeIn  {from{opacity:0} to{opacity:1}}
@keyframes sheetUp {from{transform:translateY(100%)} to{transform:translateY(0)}}
@keyframes toastIn {from{opacity:0;transform:translate(-50%,12px) scale(.9)} to{opacity:1;transform:translate(-50%,0) scale(1)}}
@keyframes shimmer {from{background-position:-200% 0} to{background-position:200% 0}}
@keyframes pulse   {0%,100%{opacity:1} 50%{opacity:.35}}
```
- Tab-content mount: `pop .45s cubic-bezier(.3,1.4,.55,1) both`
- Bottom sheet: overlay `fadeIn .25s`, panel `sheetUp .45s cubic-bezier(.3,1.25,.55,1)`
- Grade row / quiz explanation reveal: `rise .35s`
- Import result rows: `rise .4s` with staggered `animation-delay` (row index × .045s, capped ~14)
- Import "working" progress bar: `shimmer 1.3s linear infinite`; status dot `pulse 1.1s`
- Buttons: `transform:scale(.97)` on `:active`
- **Card flip** (see Cards below): `transition: transform .65s cubic-bezier(.3,1.25,.5,1)`

Respect a "Calm" option if you add settings later: swap the `pop` mount for `fadeIn .25s`.

---

## Screens / Views

Overall shell (all tabs share it):
- **Header** — fixed top, glass bar (`--bar-bg` + `backdrop-filter:var(--bar-blur)`,
  1px bottom border `rgba(255,255,255,.4)`, gradient fade `rgba(255,255,255,.55)→.15`).
  Left: 26×26 rounded-square **Finnish-flag logo** drawn in CSS (white tile, one
  horizontal `#002f6c` bar `top:10px;height:6px` + one vertical bar `left:8px;width:6px`)
  next to "Suomi Studio" (800/16.5px). Right: a **level chip** pill
  (`rgba(26,85,165,.1)` bg, `#0b3f8f` text, target/crosshair SVG) showing e.g. "B1 · Work",
  and a round 33px **settings** button (`rgba(255,255,255,.6)`, sliders SVG).
- **Tab bar** — floating glass pill, `position:absolute;bottom:30px;left/right:14px`,
  `border-radius:30px`, `--bar-bg`, `backdrop-filter:var(--bar-blur)`, `--sh-float`.
  Five equal items, each a column: 21px line icon + 9.5px label. Active item:
  `color:#0b3f8f; background:rgba(26,85,165,.13)`, transition
  `all .3s cubic-bezier(.3,1.4,.55,1)`. Cards item shows a red due-count badge
  (top-right, `#d64545`, white 9.5px/800, `border-radius:9px`).
- **Toast** — `position:absolute;bottom:116px;left:50%`, dark glass
  `rgba(22,35,63,.92)` + `blur(10px)`, white 13px/600, `border-radius:22px`,
  `animation:toastIn .35s`.

### 1. Translate
- **Direction segmented control**: 3 buttons (Auto / FI → EN / EN → FI) in a glass
  track (`--card-bg`, `border-radius:16px`, 4px padding). Active = primary gradient
  pill; inactive = transparent, `--muted`. `transition:all .25s`.
- **Textarea** (3 rows): glass field, `--r-field`, 16px text, `resize:none`.
- **Suggestion chips** below: `rgba(26,85,165,.1)` bg, `#1a55a5` 12px/600, pill radius.
  Tapping fills the textarea (e.g. "Mennäänkö huomenna saunaan?").
- **Translate button**: full-width primary. Label → "Translating…" while busy.
- **Result card** (glass, `--r-card`, `--sh-card`, `pop` in): big translation (21/700),
  dictionary form (13.5/700 `--blue-link`), grammar notes (13.5 `--muted`,
  `white-space:pre-line`), and a green "✓ Flashcard created: …" hint row
  (check SVG + 12.5/700 `--green`).
- **Recent translations** list: glass tiles, `fi` (700) over `en` (`--muted`).

### 2. Cards  *(priority screen)*
Deck-overview mode:
- **Stats card** (glass, `--r-card`=24 here): three centred columns — **due now**
  (38/800 `--blue-mid`), **total cards** (38/800 text), **learned** (38/800 `--green`),
  each over an 11.5/600 `--muted` label. Below: full-width primary "Study now"
  (disabled → "Nothing due — hyvää työtä!").
- **Add row**: two glass inputs (Finnish / English) + 46px square primary "+" button.
- **Search** field with left magnifier SVG.
- **Card list**: glass tiles — `fi` (700) / `en` (`--muted`) / meta line
  ("from transcript · next: now", `--faint` 11.5px) + a red ✕ delete button.

Study mode (entered by "Study now"):
- Top row: **Exit** link (chevron-left, `--blue-link`) + "N left" counter.
- **Progress bar**: 5px, track `rgba(22,35,63,.1)`, fill blue gradient,
  `transition:width .4s cubic-bezier(.3,1.2,.5,1)`.
- **Flip card** — 280px min-height, `perspective:1100px` on the wrapper; inner has
  `transform-style:preserve-3d` and `transition:transform .65s cubic-bezier(.3,1.25,.5,1)`.
  - **Front** (`backface-visibility:hidden`): glass, source label (11.5/700 uppercase
    `--faint`), Finnish word (30/800), "tap to reveal" hint.
  - **Back** (`transform:rotateY(180deg)` + `backface-visibility:hidden`): **blue
    gradient** `linear-gradient(170deg,rgba(34,100,196,.92),rgba(0,47,108,.95))`, white
    text — English (27/800) + optional note.
  - Tapping the card or "Show answer" sets flipped state → wrapper `transform:rotateY(180deg)`.
- **Grade row** (appears after reveal, `rise` in): 4 equal buttons — **Again** `--red`
  /10 min · **Hard** `--amber`/12 h · **Good** `--green`/2 d · **Easy** `--blue-link`/5 d.
  Each: white 14/800 label + small interval subtitle, colored shadow, `:active scale(.93)`.
  > **⚠ Flip-reset gotcha (must implement):** when advancing to the next card, reset the
  > flip to front-facing **without** the transition — otherwise the next card's back face
  > visibly rotates away. Set `transition:none` for one frame (or re-key the element per
  > card id) on advance, then restore the .65s transition so only the *reveal* animates.
- **Session-complete card**: glass, 64px blue-gradient check badge, "Loistavaa!" (24/800),
  "Session done — N cards reviewed", Done button.

### 3. Notes
- Intro line + **add row**: glass input + 50px primary "+" button.
- Note tiles: text (700) + timestamp (`--faint`), a **"→ card"** button
  (bordered `rgba(26,85,165,.3)`, `rgba(26,85,165,.06)` bg, `--blue-link` 12.5/700) that
  shows "…" while translating then toasts "Card created: …", and a red ✕.

### 4. Import  *(flagship feature — make it shine)*
- **Feature hero banner**: blue gradient card
  `linear-gradient(135deg,rgba(34,100,196,.94),rgba(0,47,108,.96))`, white text, a
  blurred white circle decoration top-right. Headline with sparkle SVG:
  "AI extraction, tuned to you". Body: "Paste a meeting transcript or any text — Claude
  picks the **20–30 words and phrases above your level (B1)** that match your focus
  (Work & business), and skips everything you already know."
- **Transcript textarea** (7 rows, glass) + a "Use a sample meeting transcript" link.
- **Extract button** (primary). On tap → **working state**: glass card with a pulsing dot
  + staged status messages ("Reading the transcript…" → "Claude found 47 candidate
  words…" → "Filtering to your level (B1) and focus (Work & business)…") and a shimmering
  progress bar. (In the real app this is the `/api/extract` call; keep the staged copy as
  loading messages.)
- **Results**: header "Found N above B1" + "toggle all". Each result is a selectable glass
  row (checkbox tile that fills with blue gradient when checked; unchecked rows dim to
  `opacity:.45`), Finnish (700) / English / short note, and a **level badge** on the right:
  B1 `rgba(26,85,165,.12)/#1a55a5`, B2 `rgba(11,63,143,.16)/#0b3f8f`, C1 `#0b3f8f`/white.
  Rows animate in staggered (`rise`). Bottom: "Add N selected to flashcards".
- **Added confirmation**: green check badge, "N cards added", "Study them now" +
  "Import another text".

### 5. Grammar
- **Level pills** row (horizontal scroll): 0 / A1 / A2 / B1 / B2 / C1, each with a
  "done/total" fraction. Selected = primary gradient; the user's *own* level gets an
  `outline:2px solid rgba(26,85,165,.4)`.
- **Level header card**: "B1 — Intermediate", tagline + "N/M done", green progress bar.
- **Topic checklist**: glass tiles — a round check toggle (green gradient when done;
  done titles go `--faint` + strikethrough), title/desc, and a "📖 Lesson & quiz" button
  (bordered blue) that shows the score % once taken.
- **Lesson view**: back link, title, a reference card (intro paragraphs + a 3-column
  table with `rgba(26,85,165,.1)` header + a tip line), then a **Quiz** card: one question
  at a time, options that turn green (correct) / red (wrong picked) / faded on answer, a
  "why" explanation, Next → and a final score. **≥80% auto-ticks the topic** off the
  checklist (and toasts "Topic ticked off automatically — 80%+"). Curriculum content comes
  from the existing `grammar.js` — do not rewrite it; only two lessons (KPT, Partitive)
  are fully fleshed in the prototype, the rest use their checklist descriptions.

### Bottom sheets (Goals & Settings)
Both slide up from the bottom (`sheetUp`), `border-radius:30px 30px 0 0`, strong glass
`rgba(255,255,255,.85)` + `blur(30px)`, a grab-handle bar, dim overlay behind
(`rgba(10,20,40,.35)`, tap to dismiss).
- **Goals**: level as pill buttons (0–C1), focus area as pill buttons (Everyday / Work &
  business / Healthcare & nursing / Tech & IT / Other), explanatory note, Save. Saving
  updates the header chip AND opens Grammar to that level.
- **Settings**: password API-key field + hint, an **iOS-style toggle** for "Auto-flashcard
  from every translation" (track green when on, knob slides `left:3px↔23px`,
  `transition:.25s cubic-bezier(.3,1.4,.55,1)`), a monospace "on your iPhone: http://…8613"
  hint, Export backup link + Save.

*(The current app uses centered `.modal` dialogs; convert these two to bottom sheets.)*

---

## Interactions & Behavior
- **Tabs**: switch via bottom bar; content remounts with `pop`. Cards badge = count of due cards.
- **Translate**: POST `/api/translate` (unchanged). On success render result card; if
  auto-card is on, create a flashcard and show the green hint; prepend to history.
- **Study**: build queue from due cards; flip to reveal; grade advances the SRS
  (`gradeCard` in `app.js`, unchanged) — "Again" requeues at the end, others remove from
  session; show completion card when queue empties. **Apply the flip-reset gotcha above.**
- **Notes → card**: POST `/api/translate` with the note text, add resulting card.
- **Import**: POST `/api/extract` (unchanged); show staged loading copy; render selectable
  results with level badges; add checked items as `transcript`-source cards.
- **Grammar**: pick level → checklist; open lesson → quiz; ≥80% marks `grammarDone[id]` and
  saves `grammarScores[id]` (existing logic). Manual check toggles also persist.
- **Goals/Settings**: persist to `data.settings` via existing `save()` (debounced POST
  `/api/data`).

## State Management
Unchanged from `app.js` — a single `data` object (`cards, notes, history, grammarScores,
grammarDone, settings`) persisted to `data.json` through the server; plus transient UI
state (current tab, study queue, quiz progress, sheet open). No new backend state is
introduced by the redesign.

## Assets / Icons
- **No image assets** beyond the existing `public/icon.png` (PWA icon — keep).
- **Emoji → inline SVG line icons.** Replace tab-bar and header emoji with 21px (tabs) /
  13–16px (header) inline `<svg>` using `stroke="currentColor" stroke-width≈1.9–2`,
  `stroke-linecap/linejoin:round`, no fill. Icons needed: translate (two arrows),
  cards (stacked rounded rects), notes (pencil), import (down-arrow into a doc),
  grammar (open book), target/crosshair (level chip), sliders (settings), magnifier,
  plus, check, chevron-left, ✕ (two crossed lines), sparkle (import hero). All are simple
  geometric paths — see `Suomi Studio.dc.html` for exact `d` attributes to copy.
- **Finnish flag logo** is pure CSS (see Header).

## Files
- **Design reference (this bundle):** `Suomi Studio.dc.html` — the interactive prototype.
- **Your codebase (edit in place):**
  - `public/style.css` — main work: rewrite with tokens/glass/animations above.
  - `public/index.html` — swap emoji for SVGs; convert the two `.modal`s to bottom sheets;
    add the flip-card structure in the study area.
  - `public/app.js` — small edits: SVG-aware rendering, sheet open/close, card-flip
    reveal + flip-reset, staged import loading copy, toast styling. Keep all logic/SRS.
  - `public/grammar.js`, `server.py` — leave as-is.

## Suggested build order
1. Tokens + backdrop + glass card mixin in `style.css`.
2. Header + floating glass tab bar (+ SVG icons).
3. Translate, Notes (simplest tabs) to validate the system.
4. Cards deck + **study flip flow** (mind the flip-reset gotcha).
5. Import (hero banner + staged loading + selectable results).
6. Grammar (pills, checklist, lesson/quiz).
7. Convert Settings & Goals modals to bottom sheets; iOS toggle.
8. Toast + micro-interactions pass.
